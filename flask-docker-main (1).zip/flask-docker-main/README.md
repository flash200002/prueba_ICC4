1. clonar proyecto
git clone https://github.com/jfarfannet/flask-poo-docker

2. instalar virtualenv


docker-compose up -d

docker-compose down

docker volume ls